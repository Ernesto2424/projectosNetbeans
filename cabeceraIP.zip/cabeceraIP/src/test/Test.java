package test;

import operaciones.Operacion;

public class Test {

    public static void main(String[] args) {
        

       //93 53 07 97
      Operacion.decodificacion("45 00 00 2c 1f e8 40 00 f8 06 41 7a c1 92 c4 ec 93 53 07 97");
        
        //System.out.println(Operacion.TipoServicio("00")); 
//        System.out.println(Operacion.longitudTotal("002c")); 
        //System.out.println(Operacion.identificador("1fe8"));
        //System.out.println(Operacion.flags_fragmentacion("4000"));
        //System.out.println(Operacion.tiempoVida("f8"));
        //System.out.println(Operacion.protocolo("06"));
        //System.out.println(Operacion.checkSum("417a"));


 // direccion = 93 53 07 97
        //147.83.7.151
        
//        System.out.println(Operacion.direccion("93530797"));
//        System.out.println(Operacion.direccion("c192c4ec"));
        
        
        
    }








    
}
