package domain;

public class Palabra {

    private int id;
    private String significado;
    
    
    public Palabra(){}
    
    
    public Palabra(String significado){
        this.significado = significado;
    }
    

    @Override
    public String toString() {
        return this.significado ;
    }
    
    
    
    



    
}
