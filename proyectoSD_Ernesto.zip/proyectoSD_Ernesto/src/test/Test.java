package test;
import RMI.TurismoServer;
import RPC.*;
import Sockets.Servidor;
/**
 *
 * @author Personal
 */
public class Test {

    public static void main(String[] args) {
        
//         RMI.TurismoServer.iniciarServidorRMI();

//        Sockets.Servidor.iniciarServidorSockets();
//        RMI.TurismoServer.iniciarServidorRMI();
         RPC.Servidor.iniciarServidorRPC();
         
         
//       Sockets.Servidor.iniciarServidorSockets();


       
      
        
        
        
        
        
    }


    
}
