/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;
import RMI.TurismoCliente;
import RPC.*;
import Sockets.Cliente;
/**
 *
 * @author Personal
 */
public class TestCliente {
    
    public static void main(String[] args) {

        RPC.Cliente.iniciarClienteRPC();
        
        
//        RMI.TurismoCliente.iniciarClienteRMI();
//        Sockets.Cliente.iniciarClienteSockets();
//        
        

    }
    
}
